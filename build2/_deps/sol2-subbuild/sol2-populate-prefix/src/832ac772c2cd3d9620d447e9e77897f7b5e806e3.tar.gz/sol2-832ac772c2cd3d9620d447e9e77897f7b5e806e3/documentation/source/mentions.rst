mentions
========
*so does anyone cool use this thing...?*

First off, feel free to `tell me about your uses!`_

Okay, so the features don't convince you, the documentation doesn't convince you, you want to see what *other* people think about sol? Well, aside from the well-wishes that come through in the issue tracker, here's a few things floating around about sol2 that I occasionally get pinged about:

`eevee`_ demonstrating the sheer code reduction by using sol2:


.. |before| image:: media/eevee_code_before.jpg
	:target: https://twitter.com/eevee/status/762039984085798913
	:alt: Plain C API
	:align: middle

.. |after| image:: media/eevee_code_after.jpg
	:target: https://twitter.com/eevee/status/762039984085798913
	:alt: Now with sol2!
	:align: middle

+----------+---------+
| |before| | |after| |
+----------+---------+

* In `Perforce`_ (later versions of the code using sol2 more directly can be requested by e-mailing support@perforce.com !)
* For Sandboxing `Fun`_!
* In `High Performance Computing research`_
	- `Published research, too!`_
* The `Multiple Arcade Machine Emulator (MAME)`_ project switched from using LuaBridge to sol2!
	- `The pull request`_ in which it was introduced to the master branch.
* For scripting, in `OpenMPT`_
* (CppNow) sol2 was mentioned in a comparison to other scripting languages by ChaiScript developer, Jason Turner (@lefticus), at a conference!
	- `Jason Turner's presentation`_
* (CppCast) Showed up in CppCast with Elias Daler!
	- `Elias Daler's blog`_
	- `CppCast`_
* (Eevee) A really nice and neat developer/artist/howaretheysotalented person is attempting to use it for zdoom!
	- `eevee's blog`_ 
* (Twitter) Twitter has some people that link it:
	- The image above, `tweeted out by eevee`_
	- Eevee: `"I heartily recommend sol2"`_
	- Elias Daler: `"sol2 is making usertypes in Lua so awesome <3"`_
	- Racod's Lair: `"from outdated LuaBridge to superior #sol2"`_
* (Reddit) Posts on reddit about it!
	- `sol2's initial reddit release`_
	- `Benchmarking Discussing`_
* Somehow landed on a Torque3D thread...
	- http://forums.torque3d.org/viewtopic.php?f=32&t=629&p=5246&sid=8e759990ab1ce38a48e896fc9fd62653#p5241

Are you using sol2 for something neat? Want it to be featured here or think it's unfair that ThePhD hasn't found it yet? Well, drop an issue in the repo or send an e-mail!

.. _tell me about your uses!: https://github.com/ThePhD/sol2/issues/189
.. _eevee: https://twitter.com/eevee
.. _eevee's blog: https://eev.ee/dev/2016/08/07/weekly-roundup-three-big-things/
.. _Fun: https://blog.rubenwardy.com/2020/07/26/sol2-script-sandbox/
.. _Jason Turner's presentation: https://github.com/lefticus/presentations/blob/master/WhyAndHowToAddScripting.md
.. _Elias Daler's blog: https://eliasdaler.github.io/cppcast#read-more
.. _CppCast: http://cppcast.com/2016/07/elias-daler/
.. _tweeted out by eevee: https://twitter.com/eevee/status/762039984085798913
.. _"I heartily recommend sol2": https://twitter.com/eevee/status/762040086540144644
.. _"from outdated LuaBridge to superior #sol2": https://twitter.com/racodslair/status/754031870640267264
.. _"sol2 is making usertypes in Lua so awesome <3": https://twitter.com/EliasDaler/status/778708299029946368
.. _sol2's initial reddit release: https://www.reddit.com/r/cpp/comments/4a8gy7/sol2_lua_c_binding_framework/
.. _Benchmarking Discussing: https://www.reddit.com/r/cpp/comments/4x82hd/plain_c_versus_lua_libraries_benchmarking_speed/
.. _"After spending hours with sol2, it wins. Amazing lib.": https://twitter.com/EliasDaler/status/739215685264494593
.. _Multiple Arcade Machine Emulator (MAME): http://www.mamedev.org/index.php
.. _The pull request: https://github.com/mamedev/mame/pull/1626
.. _OpenMPT: https://openmpt.org/
.. _High Performance Computing research: https://github.com/ThePhD/sol2/issues/568
.. _Published research, too!: https://twitter.com/thephantomderp/status/1090194999025778688
.. _Perforce: https://swarm.workshop.perforce.com/projects/perforce_software-p4/files/2018-2/script
